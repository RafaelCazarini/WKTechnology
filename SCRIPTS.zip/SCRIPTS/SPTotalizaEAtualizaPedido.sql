DELIMITER $$

CREATE PROCEDURE SPTotalizaEAtualizaPedido(
    IN p_CodPed INT  -- Código do pedido a ser atualizado
)
BEGIN
    DECLARE p_VlrTot DECIMAL(10, 2); 

    -- Calcula o total do pedido
    SELECT SUM(VlrUni * QtdPed) INTO p_VlrTot
    FROM ItemPedido
    WHERE CodPed = p_CodPed;

    -- Atualiza o campo VlrTot na tabela Pedidos
    UPDATE Pedidos
    SET VlrTot = p_VlrTot
    WHERE CodPed = p_CodPed;
END $$

DELIMITER ;
