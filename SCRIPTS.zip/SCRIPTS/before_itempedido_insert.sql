DELIMITER $$

CREATE TRIGGER before_itempedido_insert
BEFORE INSERT ON ItemPedido
FOR EACH ROW
BEGIN
  DECLARE maxCdItem INT;

  SELECT IFNULL(MAX(CdItem), 0) INTO maxCdItem
  FROM ItemPedido
  WHERE CodPed = NEW.CodPed;

  SET NEW.CdItem = maxCdItem + 1;
END $$

DELIMITER ;
