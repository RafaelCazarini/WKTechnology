
CREATE TABLE Produtos (CodPro INTEGER AUTO_INCREMENT NOT NULL,
                       DesPro VARCHAR(255)           NOT NULL,
                       PreVen NUMERIC(10,2)          NOT NULL,
PRIMARY KEY (CodPro),
INDEX (DesPro),
INDEX (PreVen));

CREATE TABLE Clientes (CodCli INTEGER AUTO_INCREMENT NOT NULL,
                       DesCli VARCHAR(100)           NOT NULL,
                       CodCid VARCHAR(100),
                       DsUf   CHAR(2),
PRIMARY KEY (CodCli),
    INDEX (DesCli),
    INDEX (CodCid),
    INDEX (DsUf));
    
CREATE TABLE Pedidos(CodPed INTEGER        AUTO_INCREMENT,
                     CodCli INTEGER        NOT NULL,
                     VlrTot NUMERIC(10, 2) NOT NULL,
					 DtEmi  DATE           NOT NULL,
PRIMARY KEY (CodPed),
FOREIGN KEY (CodCli) REFERENCES Clientes(CodCli));

CREATE TABLE ItemPedido (CdItem INTEGER        NOT NULL,
                         CodPed INTEGER        NOT NULL,
                         CodPro INTEGER        NOT NULL,
						 VlrPro DECIMAL(10, 2) NOT NULL,
                         VlrUni DECIMAL(10, 2) NOT NULL,
                         QtdPed DECIMAL(10, 2) NOT NULL,
PRIMARY KEY (CodPed,CdItem),
FOREIGN KEY (CodPed) REFERENCES Pedidos(CodPed));

INSERT INTO Produtos (DesPro, PreVen) 
VALUES ('Apple iPhone 14 Pro Max', 1099.00),
        ('Samsung Galaxy S23 Ultra', 999.00),
('Notebook Dell XPS 13', 1299.00),
('Smart TV LG OLED 55"', 1399.00),
('Câmera GoPro HERO10', 499.99),
('PlayStation 5', 499.00),
('Xbox Series X', 499.00),
('Fone de Ouvido Bluetooth Sony WH-1000XM5', 349.00),
('Monitor Gamer Samsung Odyssey G7', 699.00),
('Notebook Lenovo ThinkPad X1 Carbon', 1799.00),
('Detergente Líquido OMO Lavagem Perfeita 3L', 7.99),
('Sabonete Líquido Dove 250ml', 3.50),
('Shampoo Pantene 400ml', 5.50),
('Café em Pó Pilão Tradicional 500g', 4.99),
('Água Mineral Bonafont 1,5L', 1.00),
('Arroz Tio João Tipo 1 5kg', 12.50),
('Leite Longa Vida Parmalat Integral 1L', 1.99),
('Refrigerante Coca-Cola 2L', 2.99),
('Creme Dental Colgate Total 90g', 2.50),
('Chocolate Nestlé KitKat 45g', 1.25);
  
  INSERT INTO Clientes (DesCli, CodCid, DsUf) VALUES
('Maria Silva', 'São Paulo', 'SP'),
('João Pereira', 'Rio de Janeiro', 'RJ'),
('Ana Souza', 'Belo Horizonte', 'MG'),
('Carlos Oliveira', 'Porto Alegre', 'RS'),
('Fernanda Costa', 'Curitiba', 'PR'),
('Lucas Lima', 'Salvador', 'BA'),
('Bruno Santos', 'Fortaleza', 'CE'),
('Juliana Ferreira', 'Recife', 'PE'),
('Paulo Alves', 'Brasília', 'DF'),
('Amanda Rocha', 'Goiânia', 'GO'),
('Gabriel Martins', 'Florianópolis', 'SC'),
('Rafaela Nascimento', 'Manaus', 'AM'),
('Marcos Teixeira', 'Belém', 'PA'),
('Camila Ribeiro', 'Vitória', 'ES'),
('Rodrigo Batista', 'São Luís', 'MA'),
('Isabela Melo', 'Maceió', 'AL'),
('Pedro Araújo', 'Natal', 'RN'),
('Larissa Dias', 'Aracaju', 'SE'),
('Felipe Barbosa', 'Campo Grande', 'MS'),
('Julio Castro', 'Cuiabá', 'MT');




